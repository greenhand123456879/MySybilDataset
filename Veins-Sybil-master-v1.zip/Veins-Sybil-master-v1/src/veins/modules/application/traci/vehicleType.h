#pragma once
#include <iostream>
#include "veins/modules/application/traci/MyVeinsApp.h"

typedef enum VehicleType {
    PERSONAL = 0,       // 私人用途，例如轿车、SUV、皮卡车
    COMMERCIAL,     // 商业用途，例如货车、卡车、面包车
    PUBLIC_TRANSPORT, // 公共交通工具，例如公交车、电车、有轨电车
    SPECIAL_SERVICE  // 特种车辆，例如消防车、救护车、警车、清洁车、军用车辆
}VehicleType;
