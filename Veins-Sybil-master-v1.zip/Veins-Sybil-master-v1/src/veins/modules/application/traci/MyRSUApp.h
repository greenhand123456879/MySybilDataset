#pragma once
#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"
#include "veins/modules/application/traci/MytraciMessage_m.h"
#include "veins/modules/application/traci/MyRSUApp.h"
namespace veins {

class VEINS_API MyRSUApp : public DemoBaseApplLayer
{
protected:
    void onWSM(BaseFrame1609_4* wsm) override;
    void onWSA(DemoServiceAdvertisment* wsa) override;
};

} // namespace veinspace veins
