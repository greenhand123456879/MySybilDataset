#pragma once
#include <iostream>
#include "veins/modules/application/traci/MyVeinsApp.h"

typedef enum MaliciousBehavior {
    COLLUSION_ATTACK = 0, // 合谋攻击(授权问题)
    FRAUDULENT_TRANSACTION, // 虚假交易
    IDENTITY_THEFT, // 身份盗窃(非法车辆对网络的访问)
    FAKE_POSITION,// 虚假位置(我想的场景（事故位置、危险路段、行人多路段、此路不通、佳通设备故障）都可以)
    DATA_BREACH, // 数据泄露(发送的私人消息（密钥）)
    DENIAL_OF_SERVICE, // 服务拒绝攻击
    NORMAL
}MaliciousBehavior;
