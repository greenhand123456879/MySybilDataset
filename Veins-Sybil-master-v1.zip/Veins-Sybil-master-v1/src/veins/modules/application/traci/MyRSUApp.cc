#include "veins/modules/application/traci/MyRSUApp.h"
#include "veins/modules/application/traci/TraCIDemo11pMessage_m.h"
#include <string>

using namespace veins;
using namespace std;

Define_Module(veins::MyRSUApp);

void MyRSUApp::onWSA(DemoServiceAdvertisment* wsa)
{
    // if this RSU receives a WSA for service 42, it will tune to the chan
    if (wsa->getPsid() == 42) {
        mac->changeServiceChannel(static_cast<Channel>(wsa->getTargetChannel()));
    }
}

void MyRSUApp::onWSM(BaseFrame1609_4* frame)
{
    MytraciMessage* wsm = check_and_cast<MytraciMessage*>(frame);

    // this rsu repeats the received traffic update in 2 seconds plus some random delay
    sendDelayedDown(wsm->dup(), 2 + uniform(0.01, 0.2));

}
