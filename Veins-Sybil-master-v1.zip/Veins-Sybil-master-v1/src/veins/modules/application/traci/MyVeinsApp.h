//
// Copyright (C) 2016 David Eckhoff <david.eckhoff@fau.de>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// SPDX-License-Identifier: GPL-2.0-or-later
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#pragma once

#include "veins/veins.h"
#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"
#include "veins/modules/application/traci/MytraciMessage_m.h"
#include "veins/modules/application/traci/MyRSUApp.h"
#include "FalseLocation.h"
#include "MaliciousBehavior.h"
#include "scenarioType.h"
#include "vehicleType.h"
#include <stdio.h>
#include <string>
#include <cstring>
#include <stdlib.h>
#include <random>
#include <iostream>
#include <cassert>
#include <vector>
using namespace omnetpp;
using namespace std;

/*自定义的东西不能作为.msg文件消息发送*/

/********************定义秘钥对*******************/
typedef struct RSUKEY{      //RSU秘钥对
         int sk_RSU;
         int PK_RSU;
}RSUkey;

/********************定义时间戳*******************/
 typedef struct TIMESTAMP{
     int RSU_order;   //RSU固定序号
     SimTime Current_time;    //当前申请时间戳系统时间
     string Sig_RSU_order;   //RSU对这个时间戳的签名（证书）
 }Timestamp;

namespace veins {


class VEINS_API MyVeinsApp : public DemoBaseApplLayer {
public:
    void initialize(int stage) override;
    void finish() override;
    void dealFalsePositionEvent();
    void dealIdentityTheftEvent();
    void dealDataBreachEvent();
    void dealDosAttackEvent();
    void makeScenario(scenarioType st);
    bool isMalicious;
    MaliciousBehavior Mal_behaviorType; // label
    VehicleType vechicleTpye;           // label
    double carScore = 100;
    string vehiCertifitcate[10];
    string msgData;
    string roadData;
    Coord senderPsition;
    double senderSpeed;
   // void onBSM(DemoSafetyMessage* bsm) override;
    void onWSM(BaseFrame1609_4* frame) override;
    //void onWSA(DemoServiceAdvertisment* wsa) override;

    void handleSelfMsg(cMessage* msg) override;
    void handlePositionUpdate(cObject* obj) override;
};

} // namespace veins
