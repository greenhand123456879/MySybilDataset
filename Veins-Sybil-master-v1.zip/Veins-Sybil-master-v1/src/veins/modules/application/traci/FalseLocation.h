#pragma once

#include "veins/modules/application/traci/MyVeinsApp.h"
#include "scenarioType.h"

typedef enum scenarioType {
    ACCIDENT_LOCATION = 0, // 事故位置
    DANGEROUS_ROAD, // 危险路段
    PEDESTRIAN_HEAVY_AREA, // 行人多路段
    ROAD_CLOSED, // 此路不通
    EQUIPMENT_FAILURE // daolu设备故障
}scenarioType;

typedef struct FalseLocation {
    scenarioType scenType = ACCIDENT_LOCATION;
    double falsex; // 虚假位置的x
    double falsey; // 虚假位置的y
}FalseLocation;

