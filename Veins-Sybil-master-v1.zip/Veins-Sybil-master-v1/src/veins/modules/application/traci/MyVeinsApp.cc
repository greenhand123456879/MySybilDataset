//
// Copyright (C) 2016 David Eckhoff <david.eckhoff@fau.de>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// SPDX-License-Identifier: GPL-2.0-or-later
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include "veins/modules/application/traci/MyVeinsApp.h"
#include "veins/modules/application/traci/TraCIDemo11p.h"
#include "veins/modules/application/traci/TraCIDemo11pMessage_m.h"
#include "veins/modules/application/traci/MytraciMessage_m.h"

#define myFakeCer "123456789"
#define myTrueCer "123"
#define rsuId 10
using namespace veins;
using namespace std;

Define_Module(veins::MyVeinsApp);

void saveDataToFile(string fileName, string data) {
    ofstream file;
    file.open(fileName,ios::app);

    if (!file.is_open()) {
        cout << "Error opening file." << endl;
        return;
    }

    file << data;
    file <<'\n';
    file.close();
    cout << "Data saved to file: " << fileName << endl;
}

static bool randomBernoulliDistribution(double p)
{
    random_device rd;
    mt19937 generator(rd());
    //恶意节点伯努利分布
    bernoulli_distribution distribution(p);
    bool number = distribution(generator);
    return number;
}

static int generateRandomNumber(int begin, int end)
{
    random_device rd; // 真随机数生成器
    mt19937 gen(rd()); // 初始化 Mersenne Twister 伪随机数生成器
    uniform_int_distribution<> distr(begin, end); // 定义均匀整数分布
    return distr(gen); // 生成并返回一个在 [0, 5] 范围内的随机整数
}

static string& registerCerifitcate(int numCer)
{
    assert(numCer < 10 && numCer == 10);
    string cerifitcateBuffer[10];
    for (int n = 0; n < 10; n++)
        cerifitcateBuffer[n] = "";
    //1. for(int n = 0; n < numCer; n++)
    //registerCerifitcate algorithm

}

void MyVeinsApp::makeScenario(scenarioType st)
{
    switch (st)
    {
        case ACCIDENT_LOCATION:
        {

            break;
        }

        case DANGEROUS_ROAD:
        {

            break;
        }
        case PEDESTRIAN_HEAVY_AREA:
        {

            break;
        }
        case ROAD_CLOSED:
        {

            break;
        }
        case EQUIPMENT_FAILURE:
        {

            break;
        }
        default:
            cout << "other scenario type." << endl;
        // 其他情况
    }
}

void MyVeinsApp::dealFalsePositionEvent()
{
    this->Mal_behaviorType = FAKE_POSITION;
    makeScenario(ACCIDENT_LOCATION);//1. 把虚假位置打包，假设是这个事故场景
    //broadcast
}

void MyVeinsApp::dealIdentityTheftEvent()
{
    this->Mal_behaviorType = FAKE_POSITION;
    //1. 窃取别人的证书
    //2. 与rsu通信，然后通过rsu的可通信认证，，发布了虚假消息（把上一个的虚假信息拿来用）
    makeScenario(IDENTITY_THEFT);
    //broadcast
}

void MyVeinsApp::dealDataBreachEvent()
{
    this->Mal_behaviorType = FAKE_POSITION;
    //1. 有三辆车测，其中两辆车通信，还有一个负责窃取这两人的公钥，然后利用自己的公钥给他们发送虚假消息（把上一个的虚假信息拿来用）
    makeScenario(DATA_BREACH);
    //broadcast
}

void MyVeinsApp::dealDosAttackEvent()
{
    this->Mal_behaviorType = FAKE_POSITION;
    //拒绝访问
    makeScenario(DENIAL_OF_SERVICE);
    //broadcast
}





void MyVeinsApp::initialize(int stage)
{
    DemoBaseApplLayer::initialize(stage);
    if (0 == stage)
    {
        // Initializing members and pointers of your application goes here
        this->isMalicious = randomBernoulliDistribution(0.2);
        int Vehicle_Type = generateRandomNumber(0, 3);
        switch (Vehicle_Type)
        {
            case PERSONAL:
                this->vechicleTpye = PERSONAL;
                break;
            case COMMERCIAL:
                this->vechicleTpye = COMMERCIAL;
                break;
            case PUBLIC_TRANSPORT:
                this->vechicleTpye = PUBLIC_TRANSPORT;
                break;
            case SPECIAL_SERVICE:
                this->vechicleTpye = SPECIAL_SERVICE;
                break;
            default:
                cout << "other vehicle type." << endl;
            // 其他情况
        }
        if (this->isMalicious == true)
        {
            int Mal_behavior_Type = generateRandomNumber(0, 5);
            switch (Mal_behavior_Type)
            {
                case COLLUSION_ATTACK:
                    // 处理合谋攻击
                    break;
                case FRAUDULENT_TRANSACTION:
                    // 处理虚假交易
                    break;
                case IDENTITY_THEFT:
                    // 处理身份盗窃
                    break;
                case FAKE_POSITION:
                    // 处理虚假位置
                    //dealFalsePositionEvent();
                    break;
                case DATA_BREACH:
                    // 处理数据泄露
                    break;
                case DENIAL_OF_SERVICE:
                    // 处理服务拒绝攻击
                    break;
                default:
                    cout << "other attack type." << endl;
                // 其他情况
            }
        }
        else
        {
            int CmyId = getParentModule()->getId();                 // get yourself id
            //cout << "test CmyId: " << CmyId << endl;
            MytraciMessage* CarMsg = new MytraciMessage();
            populateWSM(CarMsg);
            CarMsg->setIsMal_behavior(false);
            CarMsg->setMsgData("this is car!");                 // 做一个合谋攻击和虚假交易的消息
            CarMsg->setRoadData(mobility->getRoadId().c_str());// get car RoadId
            CarMsg->setMysenderAddress(CmyId);                     //get car Address
            CarMsg->setVehiCertifitcate(myTrueCer);                //get car FakeCertificate
            CarMsg->setSenderSpeed(mobility->getSpeed());         //get car Speed
            CarMsg->setTimeStamp(simTime());                    //get send current time
            CarMsg->setMyrecipientAddress(rsuId);                 //get RSU Id
            CarMsg->setSenderPosition(mobility->getPositionAt(simTime()));// get simtime position
            scheduleAt(simTime() + 2 + uniform(0.01, 0.2), CarMsg->dup());
            cout << "test isMalicious" << this->isMalicious << endl;
        }
    }
    else if (1 == stage)
    {
        //正常节点初始化，发送自己位置信息

    }

//    else if (stage == 1) {
//        // Initializing members that require initialized other modules goes here
//
//        lastTime = simTime();
//
//        TraCIDemo11pMessage* Ts_req = new TraCIDemo11pMessage();    //定义申请请求
//        populateWSM(Ts_req);
//        bernoulli_distribution Rand_req(0.2);    //车辆恶意
//        int Rand_req = Rand_req(gen);
//        cout<<Rand_req<<endl;
//        string isRSU = "";  //节点类型
//
//        if(Rand_req == 1){
//            SRmsg[0] = to_string(Rand_req);
//            SRmsg[1] = to_string(myId);
//            Ts_req->setDemoData((SRmsg[0] + "||" + SRmsg[1]).data());     //发送请求  SR||唯一ID
//            scheduleAt(simTime() + uniform(0.01, 0.2), Ts_req->dup());
//            sendDown(Ts_req->dup());  //往下发消息
//            cout << "Send a request message:" << SRmsg[0] +"||"+ SRmsg[1] << endl;  //打印发送消息
//            //cancelEvent(Ts_req);
//            memset(SRmsg, 0, sizeof SRmsg);  //清空发送消息数组
//
//        }
//    }

}

void MyVeinsApp::finish()
{
    DemoBaseApplLayer::finish();
}
/**************************************
 *             1.判断是否收到消息
 *             2.处理消息代码
 * ************************************/
void MyVeinsApp::onWSM(BaseFrame1609_4* frame)
{
    MytraciMessage* rewsm = check_and_cast<MytraciMessage*>(frame);
    string rv = rewsm->getMsgData();


    cout << "—————————————————————————————————————事件结束———————————————————————————————"<< endl;  //打印接收消息
    // Your application has received a data message from another car or RSU
    // code for handling the message goes here, see TraciDemo11p.cc for examples
}

void MyVeinsApp::handleSelfMsg(cMessage* msg)
{
    MytraciMessage* wsm = dynamic_cast<MytraciMessage*>(msg);
    if (wsm)
    {
        // send this message on the service channel until the counter is 3 or higher.
        // this code only runs when channel switching is enabled
        sendDown(wsm->dup());
        cout << "==wsm->getMysenderAddress()==";
        cout << "Id: " << wsm->getMysenderAddress() << endl;
        cout << "==wsm->getMysenderAddressForUpdate()==";
        cout << "Id: " << wsm->getMysenderAddressForUpdate() << endl;
        wsm->setSerial(wsm->getSerial() + 1);
        if (wsm->getSerial() >= 3) {
            // stop service advertisements
            stopService();
            delete (wsm);
        }
        else {
            scheduleAt(simTime() + 1, wsm);
        }
    }
    else {
        DemoBaseApplLayer::handleSelfMsg(msg);
    }
}


void MyVeinsApp::handlePositionUpdate(cObject* obj)
{
//    DemoBaseApplLayer::handlePositionUpdate(obj);
//
//    TraCIDemo11pMessage* posmsg = new TraCIDemo11pMessage();    //定义位置消息
//    populateWSM(posmsg);
//    double pos_x = this->curPosition.x;
//    double pos_y = this->curPosition.y;
//
//    Pos_msg[0] = to_string(flag_posmsg);
//    Pos_msg[1] = to_string(myId);
//    Pos_msg[2] = to_string(pos_x);
//    Pos_msg[3] = to_string(pos_y);
//    Pos_msg[4] = simTime().str().c_str();   //发送消息时间
//
//    string Msg = Pos_msg[0] + "||" + Pos_msg[1] + "||" + Pos_msg[2] + "||" + Pos_msg[3] + "||" + Pos_msg[4];
//
//    posmsg->setDemoData(Msg.data());     //发送位置消息
//    sendDown(posmsg->dup());  //往下发消息
//    cout << "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++发送时间" << Pos_msg[4] << endl;
    //   cout << "Send positon message:" << Pos_msg[0] + "||" + Pos_msg[1] + "||" + Pos_msg[2] + "||" + Pos_msg[3] << endl;  //打印发送消息


    // the vehicle has moved. Code that reacts to new positions goes here.
    // member variables such as currentPosition and currentSpeed are updated in the parent class
}

